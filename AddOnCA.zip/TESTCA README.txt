# To create a test root and or issuing CA
# you can run these commands for demo
# purposes only.


# test root
.\step.exe certificate create "My Root CA" $env:temp"\Myroot-ca.crt"  $env:temp\Myroot-ca.key --profile root-ca --not-after "2035-01-01T00:00:00Z" --kty RSA --size 4096 --no-password --insecure

# issuing 
.\step.exe certificate create intermediate-ca  $env:temp"\intermediate-ca.crt"  $env:temp"\intermediate-ca.key" --profile intermediate-ca --ca  $env:temp"\Myroot-ca.crt" --ca-key  $env:temp"\Myroot-ca.key" --kty RSA --size 4096
# import the crt
# import the key
# create a certificagte credential
# (optional) delete the certificate object